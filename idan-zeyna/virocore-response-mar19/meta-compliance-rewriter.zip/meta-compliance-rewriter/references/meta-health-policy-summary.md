# Meta Health & Wellness Advertising Policy — Summary for Compliance Rewrites

Source: https://transparency.meta.com/policies/ad-standards/restricted-goods-services/health-wellness
Last verified: March 18, 2026

## Policy Structure

The policy covers two categories:
1. **Weight Loss and Cosmetic Products/Procedures**
2. **Adult Products and Reproductive Health** ← This is the relevant one for PE/ED

## What's Explicitly Allowed (18+ targeting required)

Ads promoting sexual and reproductive health products/services, including:
- Prevention of erectile dysfunction
- Premature ejaculation
- Hypoactive Sexual Desire Disorder (HSDD)
- Pain relief during sex
- Effects of menopause
- Contraceptives, condoms, lube, pheromones
- Reproductive surgeries (circumcision, vaginoplasty, vasectomy)

**Key requirement:** "the focus is on health and the medical efficacy of the product or the service and not on the sexual pleasure or enhancement"

## What's Explicitly Banned

- Sexual arousal products focused on pleasure/enhancement (sex toys, erotic products)
- Non-surgical genital enhancement products
- Adult sexual services (strip clubs, tantric services, etc.)
- Genital procedures focused on sexual pleasure (G-spot augmentation, enlargement)

## The "Focus" Test

The word "focus" is critical. Meta doesn't ban all emotional language — it bans copy where the **primary frame** is sexual pleasure. A page can have emotional copy about confidence and identity as long as the overall framing reads as health/medical.

## The Personal Attributes Policy (Second Tripwire)

Separate from Health & Wellness. Prohibits ads that imply knowledge of the viewer's medical condition.

- ✅ "New diabetes treatment available" (third-person, product exists)
- 🚫 "Do you have diabetes?" (second-person, implies knowledge)
- ✅ "A device for men working on pelvic floor strength" (general)
- 🚫 "Are you struggling with hardness?" (targets the individual)

## Safe Language List

- Muscle strengthening, pelvic floor, EMS training, rehabilitation
- Health device, clinically studied, medical-grade, non-invasive
- Natural function, physical function, "body works as it should"
- Muscle control, improved control, regain control
- Pill-free, drug-free, no medication dependency
- Morning indicators/signs (clinical health marker)
- Blood flow, muscle contraction, pelvic floor weakness
- Confidence, agency, "back to being who I am"

## Dangerous Language List

- 🚫 "In the bedroom," "bedroom life," "bedroom performance"
- 🚫 "She noticed," "partner satisfaction," "she was in shock"
- 🚫 "Last longer," "hold on longer," "a minute or two"
- 🚫 "Harder," "rock hard," "full hardness," "get hardness back"
- 🚫 "Enjoy," "feel like a man again," "celebrating again"
- 🚫 "Do you struggle with...?" "Are you losing...?"
- 🚫 Before/after performance metrics ("lasted 2 min, now 20")
- 🚫 "Satisfy your partner," "better sex," "more intense"

## LP-to-Ad Consistency Rule

Meta scans the landing page when reviewing an ad. If ad says "men's health device" but LP headline says "get your hardness back" — flagged for inconsistency. The LP and ad must tell the same story in the same register. Clean up the LP first, then match ad copy to it.

## Priority Fix Order for Any LP

1. Page title/meta tags — first thing Meta's crawler reads
2. Main headline — first thing human reviewer sees
3. CTA buttons — every link text gets scanned
4. Testimonials — highest-risk section (partner/bedroom references)
5. Results timeline — remove bedroom progress framing
6. Emotional sections — remove intimate scene narration

## How Top Brands Handle It

### Hims
- CAN say "erectile dysfunction" — it's allowed as a health condition
- DON'T say "Do you have ED?" — personal attributes violation
- Frame: "Hims helps men with ED" (product exists, man self-selects)
- Emotional hook: "Prevention. More effective than denial." (de-stigmatizing humor)

### Roman/Ro
- Tagline: "Let's Take Care Of It" — health/wellness frame, vagueness is intentional
- Ads focus on man as father/husband/son — role-based identity, not bedroom performance
- Partner framing: emotional connection and communication, never satisfaction

### BlueChew
- Internal north star: "Have Better Sex!" — but this NEVER appears in ads
- Ads use humor (instrument puns), female-forward perspective (partner support), inanimate narrators
- Brand promise in ads: "playful, confident, memorable" — three adjectives, none about pleasure

### Mojo (PE app)
- Frames problem as anxiety/mental load, not sexual performance
- "85% of ED under 40 is psychological" — medical stat + emotional validation
- Outcome language: "I stopped being in my head," "the anxiety went away"

## The Emotional Redirect Framework

The strongest compliant emotional hooks, ranked:

1. **Identity restoration** — "Feel like yourself again" / "Back to being who I am"
2. **Avoidance behavior** — "Stopped avoiding situations" / "Stopped making excuses"
3. **Body agency** — "I decide. Not the body" / "My body is mine again"
4. **Fear of betrayal** — "Terrified his body will betray him again"
5. **Quiet erosion** — "That daily erosion — that's what breaks a man"
6. **Confidence vs. anxiety binary** — "How long do you want to live in anxiety?"
7. **De-stigmatization** — "This is common. The men who thrive are the ones who acted."
