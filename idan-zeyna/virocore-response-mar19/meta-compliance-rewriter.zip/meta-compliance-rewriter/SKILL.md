---
name: Meta Compliance Rewriter
description: This skill should be used when the user asks to "make this Meta compliant", "rewrite for Meta compliance", "clean up copy for Facebook ads", "make this LP safe for Meta", "compliance rewrite", "fix flagged ad copy", or wants to rewrite landing page, ad, or funnel copy to pass Meta's Health & Wellness advertising policy while preserving emotional conversion power.
version: 1.0.0
---

# Meta Compliance Rewriter

Rewrite landing pages, ads, and funnel copy to move toward Meta compliance while preserving emotional selling power. Designed for health, wellness, and sexual health categories (PE, ED, hair loss, weight loss, supplements) where Meta's automated and human review systems flag content.

## The Core Framework

### The Real Distinction: Health/Efficacy vs. Sexual Pleasure/Enhancement

Meta's Health & Wellness policy **explicitly allows** ads for PE, ED, and sexual health products. The policy states:

> "Ads can promote sexual and reproductive health and wellness products or services, as long as the focus is on health and the medical efficacy of the product or the service and not on the sexual pleasure or enhancement."

The game is NOT hiding condition names from Meta. "Premature ejaculation" and "erectile dysfunction" are literally on the approved list. The game is ensuring the **focus** of the copy is health/medical efficacy, not sexual pleasure or enhancement.

### The Two Tripwires

1. **Sexual Pleasure/Enhancement Focus** — Copy that centers bedroom performance, partner sexual satisfaction, or the sexual act itself as the outcome.
2. **Personal Attributes Policy** — Copy that implies knowledge of the viewer's medical condition using second-person targeting ("Do you struggle with...?" "Are you losing...?").

### The Emotional Redirect: Identity, Not Pleasure

The best-converting compliant copy doesn't go clinical — it routes emotion through **identity, confidence, agency, and avoidance behavior** instead of bedroom/pleasure outcomes.

| Instead of... | Use... |
|---|---|
| Sexual pleasure/performance | Confidence, control, agency |
| Partner satisfaction | Relationship presence, connection |
| Bedroom scenes | "Situations you used to look forward to" |
| "Harder/longer/more" | "The body works as it should" |
| "She noticed/was shocked" | "I stopped avoiding life" |
| "Feel like a man again" | "Back to being who I am" |
| Duration/timing metrics | "You decide, not the body" |

## Workflow

### Step 1: Scrape the Source Copy

Use agent-browser or WebFetch to get the full content of the landing page, ad, or funnel being rewritten. Save as a reference file.

### Step 2: Load the Policy Reference

Read `references/meta-health-policy-summary.md` for the full policy details, safe/dangerous language lists, and the priority fix checklist.

### Step 3: Audit Line by Line

Go through the source copy and categorize each section:

- **✅ Already compliant** — Medical/health framing, clinical mechanisms, product specs, pricing. Leave these alone.
- **⚠️ Gray zone** — Could go either way. Identity language that implies sexual context.
- **🚫 Flaggable** — Bedroom scenes, partner reactions, sexual performance outcomes, "hardness/lasting" language, before/after performance claims.

### Step 4: Surgical Rewrite

Only change what needs to change. The principle: **keep 90% of the copy, swap the 10% that's explicitly about the sexual act or sexual outcome.**

For each flaggable line, apply the identity redirect:
- Route the emotion through who the man IS, not what he DOES in bed
- Keep visceral specificity — vague clinical language kills conversion
- Preserve voice, rhythm, and conversational tone
- Use the man's relationship with his own body as the emotional anchor

### Step 5: Format as Deliverable

Output as PromptedOS-styled HTML with:
- Hebrew (or source language) copy with RTL support
- English translation notes explaining each change
- Section-by-section compliance annotations (✅/⚠️/🚫)
- Calibration notes explaining the compliance spectrum

### Step 6: Include Calibration Guidance

Always include a note that:
- This version is intentionally over-indexed on trying to stay clean
- Many brands operate in the gray zone successfully
- If conversion drops, elements can be added back selectively
- Start from clean baseline, calibrate toward gray zone only if needed
- Test the cleaner version first before compromising

## Key Phrases That Always Work

These are emotionally powerful AND should read clean to Meta:

- "The body stopped cooperating"
- "A version of himself he doesn't recognize"
- "Terrified his body will betray him again"
- "Stopped showing up for the people who matter"
- "I decide. Not the body."
- "Back to being who I am"
- "My body is mine again"
- "Stopped avoiding life"
- "That quiet, daily erosion — that's what breaks a man"
- "You feel it before you need to prove anything"
- "Live without planning, without fear, without calculating"

## Additional Resources

### Reference Files

- **`references/meta-health-policy-summary.md`** — Full Meta Health & Wellness policy details, safe/dangerous language lists, LP-to-ad consistency rules, priority fix checklist, and how brands like Hims/Roman/BlueChew handle compliance
- **`references/identity-redirect-patterns.md`** — Detailed patterns for redirecting sexual-outcome emotions through identity/confidence framing, with before/after examples across testimonials, CTAs, headlines, symptom lists, and timelines

### Example Files

- See `clients/idan-zeyna/virocore-lp-rewrite-meta-compliant.html` for a full LP rewrite example
- See `clients/idan-zeyna/virocore-meta-compliance-examples.html` for a before/after examples document
