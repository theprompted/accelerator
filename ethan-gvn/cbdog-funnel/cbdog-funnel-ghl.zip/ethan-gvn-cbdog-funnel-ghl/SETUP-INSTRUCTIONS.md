# CBDog Funnel - GoHighLevel Setup Guide

## What's Included

### Pages (in `/pages/` folder)
1. **education-page.html** - "5 Reasons Why Exercise Won't Fix Your Dog's Anxiety"
   - This is the presell/education page (CBD-FREE - safe for paid traffic)
   - Ends with a cliffhanger CTA that links to the offer page

2. **offer-page.html** - Solution reveal + product offer
   - Contains the CBD solution reveal, product info, bundles, and checkout CTAs
   - This is where all the persuasion and conversion happens

### Images (in `/images/` folder)
- `cbdog-lamb-1-bottle.webp` - Single bottle product shot
- `cbdog-3-bottles.png` - 3-bottle bundle image
- `cbdog-6-bottles.png` - 6-bottle bundle image

---

## GoHighLevel Setup Steps

### Step 1: Upload Images to Media Library

1. Go to **Sites** > **Media Library**
2. Upload all 3 images from the `/images/` folder
3. After uploading, click each image and copy its URL
4. You'll need these URLs to update the HTML in Step 3

### Step 2: Create Funnel Structure

1. Go to **Sites** > **Funnels** > **+ Create New Funnel**
2. Name it: `CBDog Anxiety Funnel` (or similar)
3. Create two pages:
   - Page 1: `5-reasons` (or `education`)
   - Page 2: `offer`

### Step 3: Add HTML to Each Page

**For each page:**

1. Open the page in the funnel builder
2. Delete all default elements
3. Add a **Custom HTML/Code** element (full width)
4. Open the HTML file in a text editor (or VS Code)
5. Copy the entire contents
6. Paste into the Custom HTML element

### Step 4: Update Image URLs

In **offer-page.html**, find and replace these image references with your GHL media URLs:

```
src="cbdog-lamb-1-bottle.webp"  →  src="YOUR_GHL_URL_HERE"
src="cbdog-3-bottles.png"       →  src="YOUR_GHL_URL_HERE"
src="cbdog-6-bottles.png"       →  src="YOUR_GHL_URL_HERE"
```

**Tip:** Use Find & Replace (Ctrl+H or Cmd+H) in your text editor before pasting into GHL.

### Step 5: Update Internal Links

In **education-page.html**, the CTA button links to `/offer/`. Update this to match your GHL funnel URL:

Find:
```html
href="../offer/"
```

Replace with your actual offer page URL (get this from GHL after creating the page).

### Step 6: Update Checkout/Buy Links

In **offer-page.html**, find all instances of:
```
href="#"
```

Replace with your actual checkout URLs (Shopify cart links, GHL order form, etc.)

---

## Recommended URL Structure

- Education page: `yourdomain.com/cbdog` or `yourdomain.com/dog-anxiety`
- Offer page: `yourdomain.com/cbdog/offer` or `yourdomain.com/dog-anxiety/offer`

---

## Testing Checklist

- [ ] Education page loads and displays correctly
- [ ] All images appear on offer page
- [ ] CTA on education page links to offer page
- [ ] Buy buttons on offer page go to checkout
- [ ] Mobile responsive (test on phone)
- [ ] Page speed acceptable

---

## Funnel Flow

```
Paid Traffic (Facebook/Google)
         ↓
   Education Page (/5-reasons/)
   "5 Reasons Why Exercise Won't Fix Your Dog's Anxiety"
   [100% CBD-FREE - safe for ad platforms]
         ↓
   CTA: "See What Actually Works"
         ↓
    Offer Page (/offer/)
    - Solution reveal (ECS, CBD)
    - Product intro (CBDog)
    - Bundles (1/3/6 bottles)
    - Guarantee, FAQ, testimonials
         ↓
      Checkout
```

---

## Support

Questions? Contact Andrew at The Prompted.
